export default {
    plugins: {
    }
}
